// actualiza el archivo para apuntar al backend en producción

import React, { useState } from 'react'
import { useTranslation } from 'react-i18next'
import i18n from 'i18next'
import { initReactI18next } from 'react-i18next'

const resources = {
  es: {
    translation: {
      agenda_tu_cita: 'Agenda tu cita',
      nombre: 'Nombre',
      correo: 'Correo',
      fecha: 'Fecha de cita',
      comentario: 'Comentario',
      enviar: 'Enviar',
      cambio_idioma: 'Cambiar idioma'
    }
  },
  en: {
    translation: {
      agenda_tu_cita: 'Schedule your appointment',
      nombre: 'Name',
      correo: 'Email',
      fecha: 'Appointment date',
      comentario: 'Comment',
      enviar: 'Submit',
      cambio_idioma: 'Change language'
    }
  },
  it: {
    translation: {
      agenda_tu_cita: 'Prenota il tuo appuntamento',
      nombre: 'Nome',
      correo: 'Email',
      fecha: 'Data dell'appuntamento',
      comentario: 'Commento',
      enviar: 'Invia',
      cambio_idioma: 'Cambia lingua'
    }
  },
  zh: {
    translation: {
      agenda_tu_cita: '预约您的时间',
      nombre: '姓名',
      correo: '电子邮件',
      fecha: '预约日期',
      comentario: '评论',
      enviar: '发送',
      cambio_idioma: '更改语言'
    }
  }
}

i18n.use(initReactI18next).init({
  resources,
  lng: 'es',
  fallbackLng: 'es',
  interpolation: { escapeValue: false }
})

export default function TransitionCitas() {
  const { t } = useTranslation()
  const [form, setForm] = useState({ nombre: '', email: '', fecha: '', comentario: '' })
  const [idioma, setIdioma] = useState('es')
  const [mensaje, setMensaje] = useState('')

  const enviarFormulario = async (e) => {
    e.preventDefault()
    try {
      const res = await fetch('https://transition-agenda-backend.onrender.com/api/agendar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      })
      const data = await res.json()
      if (res.ok) {
        setMensaje(t('Cita enviada con éxito'))
        setForm({ nombre: '', email: '', fecha: '', comentario: '' })
      } else {
        setMensaje(t('Error al enviar la cita'))
      }
    } catch (error) {
      setMensaje(t('Error al enviar la cita'))
    }
  }

  const cambiarIdioma = (e) => {
    const lang = e.target.value
    setIdioma(lang)
    i18n.changeLanguage(lang)
  }

  return (
    <div className="p-8 max-w-md mx-auto bg-white rounded-2xl shadow-lg border border-yellow-400">
      <h1 className="text-2xl font-bold text-yellow-600 mb-4">⚡ {t('agenda_tu_cita')}</h1>
      <form onSubmit={enviarFormulario} className="flex flex-col gap-4">
        <input className="border p-2 rounded" type="text" placeholder={t('nombre')} value={form.nombre} onChange={e => setForm({ ...form, nombre: e.target.value })} required />
        <input className="border p-2 rounded" type="email" placeholder={t('correo')} value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required />
        <input className="border p-2 rounded" type="date" value={form.fecha} onChange={e => setForm({ ...form, fecha: e.target.value })} required />
        <textarea className="border p-2 rounded" placeholder={t('comentario')} value={form.comentario} onChange={e => setForm({ ...form, comentario: e.target.value })} />
        <button type="submit" className="bg-yellow-500 hover:bg-yellow-600 text-white p-2 rounded">⚡ {t('enviar')}</button>
      </form>
      {mensaje && <p className="text-green-600 mt-4">{mensaje}</p>}

      <div className="mt-4">
        <label className="block mb-1 font-medium text-gray-700">{t('cambio_idioma')}:</label>
        <select value={idioma} onChange={cambiarIdioma} className="border p-2 rounded">
          <option value="es">Español</option>
          <option value="en">English</option>
          <option value="it">Italiano</option>
          <option value="zh">中文</option>
        </select>
      </div>

      <footer className="mt-6 text-center text-sm text-gray-500">
        Transition ⚡ - Energía que conecta, compromiso que perdura.
      </footer>
    </div>
  )
}
